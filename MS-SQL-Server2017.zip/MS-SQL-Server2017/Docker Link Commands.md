
he following Docker images are used in this sample

microsoft/aspnetcore-build:2.0
microsoft/aspnetcore:2.0
For Linux Containers

 
docker build -t mssql-server .

docker build -t aspnet-albumviewer .



Run DB server in detached mode
docker run -it -d --name db-server mssql-server


Linking the db to web app container while startying

docker run -it -d -p 5000:80 --link db-server:db --name webapp aspnet-albumviewer

To add the Database table files into db from .sql files
docker exec -it mssql-server "bash"
/opt/mssql-tools/bin/sqlcmd -S localhost -U SA -P 'DockerCon!!!' -i /opt/mssql-scripts/ServerData.sql



docker run -it -d -p 5000:80 --name album-container aspnet-albumviewer

Remove the instance after execution
docker run -it --rm -p 5000:80 --name aspnetcore-container aspnetcore-app

After the application starts, visit http://<docker-machine ip>:5000 in your web browser.

http://192.168.99.100:5000/

 
Run docker ps to see your running containers. 
The "aspnetcore-container" container should be there.

Run 
docker exec aspnetcore-container ipconfig
-->ip address of container doisplayed
Copy the container IP address and paste into your browser (for example, 172.29.245.43).

You can produce an application that is ready to deploy to production locally using the dotnet publish command.

  
dotnet publish -c release -o published
 

The -c release argument builds the application in release mode (the default is debug mode). For more information, see the dotnet run reference on command-line parameters.

You can run the application on Windows using the following command.

 
dotnet published\aspnetapp.dll

ou can run the application on Linux or macOS using the following command.

 
dotnet published/aspnetapp.dll

To push the image to DockerHub

  Publish the image on docker hub in the format
  docker tag image username/repository:tag

 docker tag aspnetcore-app pbadhe34/my-apps:aspnetcore

 docker login


Upload your tagged image to the repository:

  docker push pbadhe34/my-apps:aspnetcore

Pull and run the image from the remote repository
From now on, you can use docker run and run your app on any machine with this command in the format
docker run -p 4000:80 username/repository:tag

docker run -p 4000:80 pbadhe34/my-apps:aspnetcore

